const API_URL = 'http://localhost:3000/api';

// --- UTILIDADES ---
const showLoader = () => document.getElementById('loader').classList.remove('hidden');
const hideLoader = () => document.getElementById('loader').classList.add('hidden');
const toggleView = (viewId) => {
    document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
    document.getElementById(viewId).classList.remove('hidden');
};
const switchTab = (tabId) => {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).classList.remove('hidden');
    event.target.classList.add('active');
};

const iniciarReloj = () => {
    const opciones = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
    setInterval(() => {
        const str = new Date().toLocaleDateString('es-ES', opciones);
        document.getElementById('reloj-admin').innerText = str;
        document.getElementById('reloj-alumno').innerText = str;
    }, 1000);
};
iniciarReloj();

const cerrarSesion = () => { toggleView('view-login'); document.getElementById('form-login').reset(); };

// --- LOGIN ---
document.getElementById('toggle-pass').addEventListener('click', function() {
    const input = document.getElementById('login-pass');
    if (input.type === 'password') { input.type = 'text'; this.innerText = '🙈'; } 
    else { input.type = 'password'; this.innerText = '👁'; }
});

document.getElementById('form-login').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btn-entrar');
    btn.disabled = true; showLoader();

    try {
        const res = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                usuario: document.getElementById('login-user').value,
                password: document.getElementById('login-pass').value
            })
        });
        const data = await res.json();
        
        if (data.success) {
            if (data.role === 'admin') {
                toggleView('view-admin');
                cargarTablaHorarios();
                cargarTablaAlumnos();
            } else {
                toggleView('view-alumno');
                document.getElementById('alumno-welcome').innerText = `Bienvenido ${data.nombre}`;
                cargarDirectorio();
            }
        } else {
            alert(data.message);
        }
    } catch (error) {
        alert("Error de conexión al servidor.");
    } finally {
        btn.disabled = false; hideLoader();
    }
});

// --- ADMIN: HORARIOS ---
let horarioFile = null;
document.getElementById('admin-foto').addEventListener('change', (e) => {
    horarioFile = e.target.files[0];
    if (horarioFile) {
        const reader = new FileReader();
        reader.onload = (e) => document.getElementById('admin-foto-preview').innerHTML = `<img src="${e.target.result}">`;
        reader.readAsDataURL(horarioFile);
    }
});

const limpiarFormHorarios = () => {
    document.getElementById('form-horarios').reset();
    document.getElementById('horario-id').value = "";
    document.getElementById('admin-foto-preview').innerHTML = "👤";
    horarioFile = null;
    document.querySelectorAll('#tabla-horarios tr').forEach(tr => tr.classList.remove('selected'));
};
document.getElementById('btn-limpiar-hr').addEventListener('click', limpiarFormHorarios);

const cargarTablaHorarios = async () => {
    showLoader();
    try {
        const res = await fetch(`${API_URL}/horarios`);
        const data = await res.json();
        const tbody = document.querySelector('#tabla-horarios tbody');
        tbody.innerHTML = "";
        
        // Llenar datalists para autocompletado
        const maestros = new Set(), materias = new Set(), salones = new Set();

        data.forEach(row => {
            maestros.add(row.maestro); materias.add(row.materia); salones.add(row.salon);
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${row.id}</td><td>${row.maestro}</td><td>${row.materia}</td><td>${row.salon}</td><td>${row.dia}</td><td>${row.hora}</td>`;
            tr.onclick = async () => {
                document.querySelectorAll('#tabla-horarios tr').forEach(t => t.classList.remove('selected'));
                tr.classList.add('selected');
                document.getElementById('horario-id').value = row.id;
                document.getElementById('admin-maestro').value = row.maestro;
                document.getElementById('admin-materia').value = row.materia;
                document.getElementById('admin-salon').value = row.salon;
                document.getElementById('admin-dia').value = row.dia;
                document.getElementById('admin-hora').value = row.hora;
                
                // Cargar imagen
                showLoader();
                const resFoto = await fetch(`${API_URL}/horarios/foto/${row.id}`);
                const dataFoto = await resFoto.json();
                if (dataFoto.foto) {
                    document.getElementById('admin-foto-preview').innerHTML = `<img src="${dataFoto.foto}">`;
                } else {
                    document.getElementById('admin-foto-preview').innerHTML = "👤";
                }
                hideLoader();
            };
            tbody.appendChild(tr);
        });

        // Actualizar datalists
        document.getElementById('lista-maestros').innerHTML = [...maestros].map(m => `<option value="${m}">`).join('');
        document.getElementById('lista-materias').innerHTML = [...materias].map(m => `<option value="${m}">`).join('');
        document.getElementById('lista-salones').innerHTML = [...salones].map(s => `<option value="${s}">`).join('');

    } catch (e) { alert("Error cargando horarios"); }
    finally { hideLoader(); }
};

document.getElementById('form-horarios').addEventListener('submit', async (e) => {
    e.preventDefault();
    if(document.getElementById('horario-id').value) {
        alert("Utiliza el botón Actualizar si el registro ya existe.");
        return;
    }
    
    const formData = new FormData();
    formData.append('maestro', document.getElementById('admin-maestro').value);
    formData.append('materia', document.getElementById('admin-materia').value);
    formData.append('salon', document.getElementById('admin-salon').value);
    formData.append('dia', document.getElementById('admin-dia').value);
    formData.append('hora', document.getElementById('admin-hora').value);
    if (horarioFile) formData.append('foto', horarioFile);

    showLoader();
    try {
        const res = await fetch(`${API_URL}/horarios`, { method: 'POST', body: formData });
        const data = await res.json();
        if (res.ok) { alert("Clase guardada"); limpiarFormHorarios(); cargarTablaHorarios(); } 
        else { alert(data.message); }
    } catch (e) { alert("Error al guardar"); }
    finally { hideLoader(); }
});

document.getElementById('btn-actualizar-hr').addEventListener('click', async () => {
    const id = document.getElementById('horario-id').value;
    if (!id) return alert("Selecciona un registro de la tabla.");
    
    const formData = new FormData();
    formData.append('maestro', document.getElementById('admin-maestro').value);
    formData.append('materia', document.getElementById('admin-materia').value);
    formData.append('salon', document.getElementById('admin-salon').value);
    formData.append('dia', document.getElementById('admin-dia').value);
    formData.append('hora', document.getElementById('admin-hora').value);
    if (horarioFile) formData.append('foto', horarioFile);

    showLoader();
    try {
        const res = await fetch(`${API_URL}/horarios/${id}`, { method: 'PUT', body: formData });
        if (res.ok) { alert("Registro actualizado"); limpiarFormHorarios(); cargarTablaHorarios(); }
    } catch (e) { alert("Error al actualizar"); }
    finally { hideLoader(); }
});

document.getElementById('btn-eliminar-hr').addEventListener('click', async () => {
    const id = document.getElementById('horario-id').value;
    if (!id) return alert("Selecciona un registro de la tabla.");
    if (!confirm("¿Eliminar este registro?")) return;

    showLoader();
    try {
        const res = await fetch(`${API_URL}/horarios/${id}`, { method: 'DELETE' });
        if (res.ok) { alert("Registro eliminado"); limpiarFormHorarios(); cargarTablaHorarios(); }
    } catch (e) { alert("Error al eliminar"); }
    finally { hideLoader(); }
});

// --- ADMIN: ALUMNOS ---
const limpiarFormAlumnos = () => {
    document.getElementById('form-alumnos').reset();
    document.querySelectorAll('#tabla-alumnos tr').forEach(tr => tr.classList.remove('selected'));
};
document.getElementById('btn-limpiar-al').addEventListener('click', limpiarFormAlumnos);

const cargarTablaAlumnos = async () => {
    const res = await fetch(`${API_URL}/alumnos`);
    const data = await res.json();
    const tbody = document.querySelector('#tabla-alumnos tbody');
    tbody.innerHTML = "";
    data.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${row.matricula}</td><td>${row.nombre}</td>`;
        tr.onclick = () => {
            document.querySelectorAll('#tabla-alumnos tr').forEach(t => t.classList.remove('selected'));
            tr.classList.add('selected');
            document.getElementById('admin-alumno-matricula').value = row.matricula;
            document.getElementById('admin-alumno-nombre').value = row.nombre;
        };
        tbody.appendChild(tr);
    });
};

document.getElementById('form-alumnos').addEventListener('submit', async (e) => {
    e.preventDefault();
    showLoader();
    try {
        await fetch(`${API_URL}/alumnos`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                matricula: document.getElementById('admin-alumno-matricula').value,
                nombre: document.getElementById('admin-alumno-nombre').value
            })
        });
        alert("Alumno guardado/actualizado"); limpiarFormAlumnos(); cargarTablaAlumnos();
    } catch (e) { alert("Error"); }
    finally { hideLoader(); }
});

document.getElementById('btn-eliminar-al').addEventListener('click', async () => {
    const matricula = document.getElementById('admin-alumno-matricula').value;
    if (!matricula) return alert("Selecciona un alumno.");
    if (!confirm("¿Eliminar alumno?")) return;

    showLoader();
    try {
        await fetch(`${API_URL}/alumnos/${matricula}`, { method: 'DELETE' });
        alert("Alumno eliminado"); limpiarFormAlumnos(); cargarTablaAlumnos();
    } catch (e) { alert("Error"); }
    finally { hideLoader(); }
});

// --- PANEL ALUMNO: DIRECTORIO Y CALENDARIO ---
let directorioMemoria = [];

const cargarDirectorio = async () => {
    showLoader();
    try {
        const res = await fetch(`${API_URL}/directorio`);
        directorioMemoria = await res.json();
        renderizarDirectorio(directorioMemoria);
    } catch (e) { alert("Error cargando directorio"); }
    finally { hideLoader(); }
};

const renderizarDirectorio = (datos) => {
    const tbody = document.querySelector('#tabla-directorio tbody');
    tbody.innerHTML = "";
    datos.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${row.maestro}</td><td>${row.materias || '--'}</td>`;
        
        tr.onclick = async () => {
            document.querySelectorAll('#tabla-directorio tr').forEach(t => t.classList.remove('selected'));
            tr.classList.add('selected');
            
            // Llenar preview
            document.getElementById('preview-nombre').innerText = row.maestro;
            document.getElementById('preview-nombre').classList.remove('text-hint');
            document.getElementById('preview-nombre').classList.add('text-primary');
            document.getElementById('preview-data').classList.remove('hidden');
            document.getElementById('preview-materias').innerHTML = `<strong>📚 Materias:</strong><br>${row.materias || '--'}`;
            document.getElementById('preview-salones').innerHTML = `<strong>📍 Salones:</strong><br>${row.salones || '--'}`;
            document.getElementById('preview-clases').innerHTML = `<strong>📅 Total clases:</strong> ${row.total_clases}`;

            // Cargar Foto
            showLoader();
            const res = await fetch(`${API_URL}/directorio/foto/${row.maestro}`);
            const fotoData = await res.json();
            document.getElementById('preview-avatar').innerHTML = fotoData.foto ? `<img src="${fotoData.foto}">` : "👤";
            hideLoader();
        };

        tr.ondblclick = () => abrirCalendario(row.maestro);

        tbody.appendChild(tr);
    });
};

document.getElementById('search-directorio').addEventListener('input', (e) => {
    const text = e.target.value.toLowerCase();
    const filtrados = directorioMemoria.filter(row => 
        row.maestro.toLowerCase().includes(text) || 
        (row.materias && row.materias.toLowerCase().includes(text))
    );
    renderizarDirectorio(filtrados);
});

// Generar Calendario Modal
const horas = ["07:10 - 08:00", "08:00 - 08:50", "08:50 - 09:40", "09:40 - 10:30", "10:30 - 11:20", "11:20 - 12:10", "12:10 - 13:00", "13:00 - 13:50"];
const dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"];
const colores = ["#C0392B", "#2980B9", "#D35400", "#27AE60", "#8E44AD", "#16A085", "#F39C12"];

const abrirCalendario = async (maestro) => {
    document.getElementById('modal-titulo').innerText = `Horario Asignado: ${maestro}`;
    const tbody = document.getElementById('calendario-body');
    tbody.innerHTML = "";
    
    // Crear la estructura de la tabla (5x8) vacía
    horas.forEach(hora => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td class="td-hora">${hora}</td>` + dias.map(d => `<td id="celda-${d}-${hora}">-- Libre --</td>`).join('');
        tbody.appendChild(tr);
    });

    showLoader();
    try {
        const res = await fetch(`${API_URL}/directorio/calendario/${maestro}`);
        const clases = await res.json();
        
        let asignacionColores = {};
        let colorIdx = 0;

        clases.forEach(clase => {
            const td = document.getElementById(`celda-${clase.dia}-${clase.hora}`);
            if (td) {
                if (!asignacionColores[clase.materia]) {
                    asignacionColores[clase.materia] = colores[colorIdx % colores.length];
                    colorIdx++;
                }
                td.innerHTML = `<strong>${clase.materia}</strong><br>📍 ${clase.salon}`;
                td.style.backgroundColor = asignacionColores[clase.materia];
                td.style.color = "white";
            }
        });

        document.getElementById('modal-calendario').classList.remove('hidden');
    } catch (e) { alert("Error cargando el calendario"); }
    finally { hideLoader(); }
};