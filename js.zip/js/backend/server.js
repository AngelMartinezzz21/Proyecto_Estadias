require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const multer = require('multer');

const app = express();
app.use(cors());
app.use(express.json());

// Configuración de Multer para manejar archivos en memoria
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// --- CONNECTION POOL ---
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// --- ENDPOINTS (API) ---

// 1. Login
app.post('/api/login', async (req, res) => {
    const { usuario, password } = req.body;
    
    // Admin 
    if (usuario === 'admin' && password === 'Admin1900') {
        return res.json({ success: true, role: 'admin', nombre: 'Administrador' });
    }

    try {
        const [rows] = await pool.execute(
            'SELECT nombre, usuario FROM usuarios WHERE (usuario = ? OR matricula = ?) AND password = ?',
            [usuario, usuario, password]
        );

        if (rows.length > 0) {
            const nombreMostrar = rows[0].nombre ? rows[0].nombre : rows[0].usuario;
            res.json({ success: true, role: 'alumno', nombre: nombreMostrar });
        } else {
            res.status(401).json({ success: false, message: 'Usuario o contraseña incorrectos' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 2. Obtener Horarios (Admin)
app.get('/api/horarios', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT id, maestro, materia, salon, dia, hora FROM horarios ORDER BY dia, hora');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 3. Crear Horario
app.post('/api/horarios', upload.single('foto'), async (req, res) => {
    const { maestro, materia, salon, dia, hora } = req.body;
    const foto = req.file ? req.file.buffer : null;

    try {
        // Validar choques
        const [choques] = await pool.execute('SELECT maestro, salon FROM horarios WHERE dia = ? AND hora = ?', [dia, hora]);
        for (let row of choques) {
            if (row.maestro.toLowerCase() === maestro.toLowerCase()) return res.status(400).json({ message: `El maestro ya tiene clase el ${dia} a las ${hora}` });
            if (row.salon.toLowerCase() === salon.toLowerCase()) return res.status(400).json({ message: `El salón está ocupado el ${dia} a las ${hora}` });
        }

        await pool.execute(
            'INSERT INTO horarios (maestro, materia, salon, dia, hora, foto) VALUES (?, ?, ?, ?, ?, ?)',
            [maestro, materia, salon, dia, hora, foto]
        );
        
        if (foto) {
            await pool.execute('UPDATE horarios SET foto = ? WHERE maestro = ?', [foto, maestro]);
        }
        
        res.json({ success: true, message: 'Clase guardada' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 4. Actualizar Horario
app.put('/api/horarios/:id', upload.single('foto'), async (req, res) => {
    const id = req.params.id;
    const { maestro, materia, salon, dia, hora } = req.body;
    const foto = req.file ? req.file.buffer : null;

    try {
        if (foto) {
            await pool.execute(
                'UPDATE horarios SET maestro=?, materia=?, salon=?, dia=?, hora=?, foto=? WHERE id=?',
                [maestro, materia, salon, dia, hora, foto, id]
            );
            await pool.execute('UPDATE horarios SET foto = ? WHERE maestro = ?', [foto, maestro]);
        } else {
            await pool.execute(
                'UPDATE horarios SET maestro=?, materia=?, salon=?, dia=?, hora=? WHERE id=?',
                [maestro, materia, salon, dia, hora, id]
            );
        }
        res.json({ success: true, message: 'Registro actualizado' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 5. Eliminar Horario
app.delete('/api/horarios/:id', async (req, res) => {
    try {
        await pool.execute('DELETE FROM horarios WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 6. Obtener Foto de Maestro (Para vista previa)
app.get('/api/horarios/foto/:id', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT foto FROM horarios WHERE id = ?', [req.params.id]);
        if (rows.length > 0 && rows[0].foto) {
            const base64 = Buffer.from(rows[0].foto).toString('base64');
            res.json({ foto: `data:image/jpeg;base64,${base64}` });
        } else {
            res.json({ foto: null });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 7. Alumnos (CRUD)
app.get('/api/alumnos', async (req, res) => {
    try {
        const [rows] = await pool.execute("SELECT matricula, nombre FROM usuarios WHERE matricula != 'admin' ORDER BY nombre");
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/alumnos', async (req, res) => {
    const { matricula, nombre } = req.body;
    try {
        const [exist] = await pool.execute('SELECT matricula FROM usuarios WHERE matricula = ?', [matricula]);
        if (exist.length > 0) {
            await pool.execute('UPDATE usuarios SET nombre=?, usuario=?, password=? WHERE matricula=?', [nombre, matricula, matricula, matricula]);
        } else {
            await pool.execute('INSERT INTO usuarios (matricula, usuario, password, nombre) VALUES (?, ?, ?, ?)', [matricula, matricula, matricula, nombre]);
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/alumnos/:matricula', async (req, res) => {
    try {
        await pool.execute('DELETE FROM usuarios WHERE matricula = ?', [req.params.matricula]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 8. Directorio (Panel Alumno)
app.get('/api/directorio', async (req, res) => {
    try {
        const [rows] = await pool.execute(`
            SELECT maestro, GROUP_CONCAT(DISTINCT materia SEPARATOR ', ') as materias, 
            COUNT(id) as total_clases, GROUP_CONCAT(DISTINCT salon SEPARATOR ', ') as salones
            FROM horarios GROUP BY maestro ORDER BY maestro
        `);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/directorio/foto/:maestro', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT foto FROM horarios WHERE maestro = ? AND foto IS NOT NULL LIMIT 1', [req.params.maestro]);
        if (rows.length > 0 && rows[0].foto) {
            res.json({ foto: `data:image/jpeg;base64,${Buffer.from(rows[0].foto).toString('base64')}` });
        } else {
            res.json({ foto: null });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/directorio/calendario/:maestro', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT materia, salon, dia, hora FROM horarios WHERE maestro = ?', [req.params.maestro]);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor corriendo en el puerto ${PORT}`));